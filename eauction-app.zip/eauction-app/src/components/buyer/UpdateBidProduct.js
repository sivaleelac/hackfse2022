import React, { Component } from 'react';

class UpdateBidProduct extends Component {
    render() {
        return (
            <div>
                Update Bid amount
            </div>
        );
    }
}

export default UpdateBidProduct;