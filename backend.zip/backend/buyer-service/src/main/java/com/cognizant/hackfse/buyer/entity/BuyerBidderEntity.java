package com.cognizant.hackfse.buyer.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.cognizant.hackfse.buyer.model.Person;
import com.cognizant.hackfse.buyer.model.Product;

import lombok.Data;

@Document(collection = "bidder")
@Data
public class BuyerBidderEntity {
	@Id
	private String id;
	private Person person;
	private Product product;
	private String bidAmount;
}
