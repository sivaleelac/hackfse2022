package com.cognizant.hackfse.buyer.entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.cognizant.hackfse.buyer.model.Person;
import com.cognizant.hackfse.buyer.model.Product;

import lombok.Data;

@Document(collection = "productbidder")
@Data
public class BuyerProductBidderEntity {
	@Id
	private String id;
	private Product product;
	private List<Bid> bids;
	
	@Data
	public static class Bid{
		private Person person;
		private String bidAmount;
	}
}
