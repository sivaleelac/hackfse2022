package com.cognizant.hackfse.buyer.client;

import org.springframework.cloud.openfeign.FallbackFactory;

import com.cognizant.hackfse.buyer.model.Product;

public class ProductClientFallbackFactory implements FallbackFactory<ProductClient>{

	@Override
	public ProductClient create(Throwable cause) {
		return new ProductClient() {
			@Override
			public Product getProductById(String productId) {
				throw new RuntimeException("Internal server error");
			}
		};
	}

}
