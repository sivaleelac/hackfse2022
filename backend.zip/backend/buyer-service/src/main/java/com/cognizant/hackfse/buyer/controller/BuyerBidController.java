package com.cognizant.hackfse.buyer.controller;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.hackfse.buyer.exception.BadRequestException;
import com.cognizant.hackfse.buyer.model.BidderResource;
import com.cognizant.hackfse.buyer.service.BidderService;

@RestController
public class BuyerBidController {

	@Autowired
	private BidderService bidderService;

	@PostMapping("/api/v1/buyer/place-bid")
	public ResponseEntity<BidderResource> addProduct(@Valid @RequestBody BidderResource bidder) {
		validateRequest(bidder);
		BidderResource response = bidderService.placeBid(bidder);

		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	private void validateRequest(BidderResource bidder) {
		if (bidder.getPerson() == null || StringUtils.isBlank(bidder.getPerson().getId())) {
			throw new BadRequestException("error.client.personId.blank");
		}
		if (bidder.getProduct() == null || StringUtils.isBlank(bidder.getProduct().getId())) {
			throw new BadRequestException("error.client.productId.blank");
		}
	}

	@PutMapping("/api/v1/buyer/update-bid/{productId}/{emailAddress}/{newBidAmount}")
	public ResponseEntity<BidderResource> updateBid(@PathVariable("productId") String productId,
			@PathVariable("emailAddress") String emailAddress, @PathVariable("newBidAmount") String newBidAmount) {

		bidderService.updateBidAmount(productId, emailAddress, newBidAmount);

		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}
