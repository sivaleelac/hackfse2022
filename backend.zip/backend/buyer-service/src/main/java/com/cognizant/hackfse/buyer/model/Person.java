package com.cognizant.hackfse.buyer.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Person {
	private String id;
	private String firstName;
	private String lastName;
	private Address address;
	private String phoneNumber;
	private String emailAddress;
	
	@Data
	@Builder
	@NoArgsConstructor
	@AllArgsConstructor
	public static class Address{
		private String city;
		private String state;
		private String pincode;
	}
}
