package com.cognizant.hackfse.seller.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.hackfse.seller.client.PersonClient;
import com.cognizant.hackfse.seller.entity.BuyerProductBidEntity;
import com.cognizant.hackfse.seller.entity.SellerProductEntity;
import com.cognizant.hackfse.seller.exception.InternalServerException;
import com.cognizant.hackfse.seller.exception.NotFoundException;
import com.cognizant.hackfse.seller.model.Person;
import com.cognizant.hackfse.seller.model.ProductBidder;
import com.cognizant.hackfse.seller.model.SellerProduct;
import com.cognizant.hackfse.seller.repository.BuyerProductBidRepository;
import com.cognizant.hackfse.seller.repository.SellerProductRepository;

@Service
public class SellerProductService {

	@Autowired
	private SellerProductRepository sellerRepository;
	@Autowired
	private BuyerProductBidRepository buyerProductBidRepository;

	@Autowired
	private PersonClient personClient;

	public SellerProduct addProduct(SellerProduct sellerProduct) {
		Person person = validateAndGetPersonById(sellerProduct.getPerson().getId());
		try {
			ModelMapper mapper = new ModelMapper();
			SellerProductEntity sellerEntityResponse = sellerRepository
					.save(buildSellerProductEntityRequest(sellerProduct, person, mapper));
			return mapper.map(sellerEntityResponse, SellerProduct.class);
		} catch (Exception exp) {
			throw new InternalServerException("Internal server error");
		}
	}

	public SellerProduct findProductById(String productId) {
		SellerProduct product = null;
		try {
			ModelMapper mapper = new ModelMapper();
			Optional<SellerProductEntity> productEntityOptional = sellerRepository.findById(productId);
			if (productEntityOptional.isPresent()) {
				return mapper.map(productEntityOptional.get(), SellerProduct.class);
			}
		} catch (Exception exp) {
			throw new InternalServerException("Something went wrong, please try again");
		}
		return product;
	}

	public void deleteProduct(String productId) {
		try {
			sellerRepository.deleteById(productId);
		} catch (Exception exp) {
			throw new InternalServerException("Something went wrong, please try again");
		}
	}
	
	public ProductBidder getProductWithBidDetails(String productId) {
		try {
			ModelMapper mapper = new ModelMapper();
			
			Optional<BuyerProductBidEntity> buyerProductBidEntityOptional = buyerProductBidRepository.findByProductId(productId);
			
			if(buyerProductBidEntityOptional.isPresent()) {
				return mapper.map(buyerProductBidEntityOptional.get(), ProductBidder.class);
			}else {
				throw new NotFoundException("Product not found");
			}
		}catch (Exception exp) {
			throw new InternalServerException("Unable to fetch product details");
		}
	}
	
	private SellerProductEntity buildSellerProductEntityRequest(SellerProduct sellerProduct, Person person,
			ModelMapper mapper) {
		SellerProductEntity sellerProductEntity = mapper.map(sellerProduct, SellerProductEntity.class);
		sellerProductEntity.setPerson(person);
		return sellerProductEntity;
	}

	private Person validateAndGetPersonById(String personId) {
		try {
			return personClient.getPersonById(personId);
		} catch (Exception exp) {
			throw new InternalServerException("Person not found");
		}
	}
}
