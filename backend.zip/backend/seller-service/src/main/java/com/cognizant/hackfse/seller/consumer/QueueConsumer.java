package com.cognizant.hackfse.seller.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.hackfse.seller.model.Bidder;
import com.cognizant.hackfse.seller.service.BuyerBidderService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class QueueConsumer {
	
	@Autowired
	private BuyerBidderService buyerBidderService;
	
	public void receiveMessage(String message) {
		// logger.info("Received (String) " + message);
		processMessage(message);
	}

	public void receiveMessage(byte[] message) {
		String strMessage = new String(message);
		// logger.info("Received (No String) " + strMessage);
		processMessage(strMessage);
	}

	private void processMessage(String message) {
		try {
			Bidder bidder = new ObjectMapper().readValue(message, Bidder.class);
			buyerBidderService.createOrUpdateBidderAndProductDetails(bidder);
		} catch (JsonParseException e) {
			// logger.warn("Bad JSON in message: " + message);
		} catch (JsonMappingException e) {
			// logger.warn("cannot map JSON to NotificationRequest: " + message);
		} catch (Exception e) {
			// logger.error(e.getMessage());
		}

	}
}
