package com.cognizant.hackfse.seller.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.hackfse.seller.exception.BadRequestException;
import com.cognizant.hackfse.seller.exception.NotFoundException;
import com.cognizant.hackfse.seller.model.SellerProduct;
import com.cognizant.hackfse.seller.model.SellerProduct.Category;
import com.cognizant.hackfse.seller.service.SellerProductService;

@RestController
public class SellerProductController {

	private final static String DATE_FORMAT = "dd/MM/yyyy";

	@Autowired
	private SellerProductService sellerProductService;

	@PostMapping("/api/v1/seller/add-product")
	public ResponseEntity<SellerProduct> addProduct(@Valid @RequestBody SellerProduct sellerProduct) {

		validateRequest(sellerProduct);

		SellerProduct addedProduct = sellerProductService.addProduct(sellerProduct);

		return new ResponseEntity<>(addedProduct, HttpStatus.CREATED);
	}

	@GetMapping("/api/v1/seller/get-product/{productId}")
	public ResponseEntity<SellerProduct> getProduct(@PathVariable("productId") String productId) {

		SellerProduct product = getProductDetails(productId);

		return new ResponseEntity<>(product, HttpStatus.OK);
	}

	@DeleteMapping("/api/v1/seller/delete/{productId}")
	public ResponseEntity<SellerProduct> deleteProduct(@PathVariable("productId") String productId) {

		SellerProduct product = getProductDetails(productId);

		validateBidEnddate(product.getBidEndDate());

		sellerProductService.deleteProduct(productId);

		return new ResponseEntity<>(HttpStatus.NO_CONTENT);

	}

	private SellerProduct getProductDetails(String productId) {
		SellerProduct product = sellerProductService.findProductById(productId);
		if (product == null) {
			throw new NotFoundException("error.client.product.notFound");
		}
		return product;
	}

	private void validateRequest(SellerProduct sellerProduct) {
		if (sellerProduct.getPerson() == null || StringUtils.isBlank(sellerProduct.getPerson().getId())) {
			throw new BadRequestException("error.client.personId.blank");
		}
		validateCategory(sellerProduct.getCategory());
		validateBidEnddate(sellerProduct.getBidEndDate());
	}

	private void validateCategory(String category) {
		if (StringUtils.isNotBlank(category) && !Category.isValidCategoryName(category)) {
			throw new BadRequestException("error.client.category.invalid");
		}
	}

	private void validateBidEnddate(String bidEnddate) {
		if (StringUtils.isNotBlank(bidEnddate)) {
			LocalDate formattedDate = getFormattedBidDate(bidEnddate);
			if (formattedDate.isBefore(LocalDate.now())) {
				throw new BadRequestException("Bid end date is before current date");
			}
		}
	}

	private LocalDate getFormattedBidDate(String bidEnddate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
		try {
			return LocalDate.parse(bidEnddate, formatter);
		} catch (DateTimeParseException e) {
			throw new BadRequestException("error.client.bidEndDate.invalid");
		}
	}
}
