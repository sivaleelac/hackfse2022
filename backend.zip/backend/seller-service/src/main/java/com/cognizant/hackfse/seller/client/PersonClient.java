package com.cognizant.hackfse.seller.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.hackfse.seller.model.Person;

@FeignClient(name = "person-service", fallbackFactory = PersonClientFallbackFactory.class)
public interface PersonClient {

	@GetMapping(value = "/api/v1/person/{personId}")
	public Person getPersonById(@PathVariable(value = "personId") String personId);
}
