package com.cognizant.hackfse.seller.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.hackfse.seller.entity.SellerProductEntity;

@Repository
public interface SellerProductRepository extends MongoRepository<SellerProductEntity, String> {

}
