package com.cognizant.hackfse.person.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.hackfse.person.exception.NotFoundException;
import com.cognizant.hackfse.person.model.Person;
import com.cognizant.hackfse.person.service.PersonService;

@RestController
public class PersonController {
    private static final Logger log = LoggerFactory.getLogger(PersonController.class);

	@Autowired private PersonService personService;

	@PostMapping("/api/v1/person")
	public ResponseEntity<Person> createPerson(@Valid @RequestBody Person person) {
		log.info("Create person details........");
		Person createdPerson = personService.createPerson(person);
		log.info("Person details created successfully........");
		return new ResponseEntity<>(createdPerson, HttpStatus.CREATED);
	}
	
	@GetMapping("/api/v1/person/{personId}")
	public ResponseEntity<Person> getPersonById(@PathVariable("personId") String personId) {

		Person person = personService.getPersonById(personId);
		
		if(person == null) {
			throw new NotFoundException("error.client.person.notFound");
		}
		
		return new ResponseEntity<>(person, HttpStatus.OK);
	}

}
